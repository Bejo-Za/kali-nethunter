<?php
	//error_reporting(0);
	ob_start();
	define('sec', 1);
	require dirname(__FILE__).'/config.php';
	if (isset($_REQUEST['k'])) {
		$key = trim(strip_tags($_REQUEST['k']));
	}
	if (isset($key) && !empty($key) && isset($files[$key])) {
		$selected_k = $key;
	} else {
		$selected_k = 'home';
	}
	require dirname(__FILE__).'/actions.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="Nethunter for Android by Offensive Security"/>
    <meta name="author" content="Offensive Security"/>

    <title>Nethunter Web Panel</title>
	<link rel="shortcut icon" href="images/favicon.ico"/>
		
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,400italic,700,800' rel='stylesheet' type='text/css'/>
	<link href='http://fonts.googleapis.com/css?family=Raleway:100' rel='stylesheet' type='text/css'/>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,700' rel='stylesheet' type='text/css'/>
  
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="css/bootstrap.css" />
	<link rel="stylesheet" href="css/application.css" >
	<link rel="stylesheet" type="text/css" href="js/jquery.select2/select2.css" />
	<link rel="stylesheet" href="fonts/font-awesome-4/css/font-awesome.min.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-switch.min.css" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->

	<!-- Custom styles for this template -->
	<link rel="stylesheet" href="css/theme-nethunter.css"  />
	<link rel="stylesheet" href="css/nanoscroller.css" />
		
  </head>
<body>
<!-- header/logo -->
<div id="head-nav" class="navbar navbar-default navbar-fixed-top">
<div class="container-fluid">
  <div class="navbar-collapse">
	<a class="navbar-brand" href="index.php"></a> <h1>Nethunter Web Panel</h1>
  </div>
</div>
</div>
