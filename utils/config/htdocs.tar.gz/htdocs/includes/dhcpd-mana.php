<?php 
	if (isset($_POST['action']) && $_POST['action'] === 'updateSource' && isset($_POST['tab']) && $_POST['tab'] == 'dhcpd'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files['dhcpd-mana']['path'], $new_source);	
		$message = 'Source updated!';
	endif;
	$con = file_get_contents($files['dhcpd-mana']['path']);
?>
<?php require dirname(__FILE__).'/messages.php';?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#dhcpdsource" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content">
	<div id="dhcpdsource" class="tab-pane fade in active">
		<form action="index.php#dhcpdsource" method="POST">
			<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			<input type="hidden" name="tab" value="dhcpd" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
