        <div class="block-flat">
          <div class="header">
            <h3>NetHunter Web Panel</h3>
			<p>Welcome to Kali Linux NetHunter! This web panel is designed to make it easier to execute attacks and control services. The navigation menu contains links to useful commands, settings, macros, and attack configuration pages. If you have any suggestions for additional features, contact us!<br /><br />
			<b>Most configurations work out of the box</b> but some may require some minimal tweaking. Make sure you read more about these attacks (links are included on each page) to get them working perfectly.</p>
          </div>
          <div class="content">

<h4>Current Interfaces</h4>
<pre>
<?php echo shell_exec("netcfg |grep UP |grep -v ^lo|awk -F\" \" '{print $1\"\t\" $3}'"); ?>
</pre>
<h4>External IP Address</h4>

<div class="well well-sm" id="external-ip">
	<a href="javascript:void(0);" onclick="return getExternalIp();" class="btn btn-success btn-sm" id="external-ip-btn">Get External IP</a>
</div>

<div class="well well-lg description">
<p><strong><font color="red">Big Fat Hairy Warning:</font></strong>
The web panel allows for the editing of various scripts, which are then executed with <b>root</b> permissions. Although this web service only listens on localhost (127.0.0.1), caution must be exercised at all times when using the web panel as CSRF attacks may allow for code execution. Ensure you stop the web service whenever it is not in use.</p>
</div>
