<?php include("header.php");?>
<?php include("menu-side.php");?>
	
	<div class="container-fluid" id="pcont">
		<div class="cl-mcont">
		
		  <!-- main content -->
			
							<?php if (isset($files[$selected_k]['include']) && is_file($files[$selected_k]['include'])):?>
								<?php include $files[$selected_k]['include']; ?>  		
							<?php else: ?>
							<?php endif;?>  

		  <!-- main content -->	
		  
		</div> <!-- .cl-mcont -->
	</div> <!-- .container-fluid -->
</div> <!-- .cl-wrapper -->

<?php include("footer.php");?>