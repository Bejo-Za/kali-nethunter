$(function() {

/********************************************************************
	Menu & Break Points
********************************************************************/

      function updateHeight(){
        if(!$("#cl-wrapper").hasClass("fixed-menu")){
          var button = $("#cl-wrapper .collapse-button").outerHeight();
          var navH = $("#head-nav").height();
          var cont = $("#pcont").height();
          var sidebar = ($(window).width() > 755 && $(window).width() < 963)?0:$("#cl-wrapper .menu-space .content").height();
          var windowH = $(window).height();
          
          if(sidebar < windowH && cont < windowH){
            if(($(window).width() > 755 && $(window).width() < 963)){
              var height = windowH;
            }else{
              var height = windowH - button - navH;
            }
          }else if((sidebar < cont && sidebar > windowH) || (sidebar < windowH && sidebar < cont)){
            var height = cont + button + navH;
          }else if(sidebar > windowH && sidebar > cont){
            var height = sidebar + button;
          }  
          
        } // if
      } // function updateHeight

      
/********************************************************************
	Hamburger Menu Toggle
********************************************************************/

      $(".cl-toggle").click(function(e){
        var ul = $(".cl-vnavigation");
        ul.slideToggle(300, 'swing', function () {
        });
        e.preventDefault();
      });

      
/********************************************************************
	Sidebar
********************************************************************/
      
      if($("#cl-wrapper").hasClass("fixed-menu")){
        var scroll =  $("#cl-wrapper .menu-space");
        scroll.addClass("nano nscroller");
 
        function update_height(){
          var button = $("#cl-wrapper .collapse-button");
          var collapseH = button.outerHeight();
          var navH = $("#head-nav").height();
          var height = $(window).height() - ((button.is(":visible"))?collapseH:0) - navH;
          scroll.css("height",height);
          $("#cl-wrapper .nscroller").nanoScroller({ preventPageScrolling: true });
        }
        
        $(window).resize(function() {
          update_height();
        });    
         		 
        update_height();
        $("#cl-wrapper .nscroller").nanoScroller({ preventPageScrolling: true });
		
      } // if

        
/********************************************************************
	Return to top
********************************************************************/

      var offset = 10;		// pixels to scroll before seeing
      var duration = 300;	// How quickly to fade in/out
      var button = $('<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>');
      button.appendTo("body");
      
      jQuery(window).scroll(function() {
        if (jQuery(this).scrollTop() > offset) {
            jQuery('.back-to-top').fadeIn(duration);
        } else {
            jQuery('.back-to-top').fadeOut(duration);
        }
      });
    
      jQuery('.back-to-top').click(function(event) {
          event.preventDefault();
          jQuery('html, body').animate({scrollTop: 0}, duration);
          return false;
      });

	  
/********************************************************************
	Select2
********************************************************************/	  

// Set all check boxes to false on page refresh
//jQuery(':checkbox:checked').prop('checked',false);
jQuery('.hidsCheck').prop('checked', false);

// Reverse TCP
    jQuery('#rtcp-elevated').click(function(){
          if(jQuery(this).is(':checked')){
              jQuery("#rtcp-platform").show().select2();
          } else {
              jQuery('#rtcp-platform').select2("destroy").hide();
          }
    });
// Powersploit
    jQuery('#powersploit-elevated').click(function(){
          if(jQuery(this).is(':checked')){
              jQuery("#powersploit-platform").show().select2();
          } else {
              jQuery('#powersploit-platform').select2("destroy").hide();
          }
    });
// Windows CMD
	jQuery("#cmd-platform").hide();
    jQuery('#cmd-elevated').click(function(){
          if(jQuery(this).is(':checked')){
              jQuery("#cmd-platform").show().select2();
          } else {
              jQuery('#cmd-platform').select2("destroy").hide();
          }
    });
	
$('.switch').bootstrapSwitch();

$('input.switch').on('switchChange.bootstrapSwitch', function(event, state){
  //console.log(this); // DOM element
  //console.log(event); // jQuery event
  //console.log(state); // true | false
	StartStopKaliServices($(this).attr('id'))}
);
/*
$('input.switch').on('switchChange.bootstrapSwitch', function(event, state) {
  console.log(this); // DOM element
  console.log(event); // jQuery event
  console.log(state); // true | false
});*/
	
/********************************************************************
	End DOM Ready
********************************************************************/ 
});