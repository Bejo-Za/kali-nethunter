jQuery(document).ready(function(){
			var url = document.location.toString();
			if (url.match('#')) {
			    $('.nav-tabs a[href=#'+url.split('#')[1]+']').tab('show') ;
			} 

			$('.nav-tabs a').on('shown', function (e) {
			    window.location.hash = e.target.hash;
			});
			
			$("#menu-toggle").click(function(e) {
		        e.preventDefault();
		        $("#wrapper").toggleClass("toggled");
		    });
			elevatorClicked('rtcp');
			elevatorClicked('powersploit');
			elevatorClicked('adsf');			
});

$(document).ready(function () {
	  $('[data-toggle=offcanvas]').click(function () {
	    if ($('.sidebar-offcanvas').css('background-color') == 'rgb(255, 255, 255)') {
		    $('.list-group-item').attr('tabindex', '-1');
	    } else {
		    $('.list-group-item').attr('tabindex', '');
	    }
	    $('.row-offcanvas').toggleClass('active');	    
	  });
	  
	  if ($('#main-alert').length){
	    	window.setTimeout(function () {
      		$('#main-alert').slideUp();
      	}, 3000);
	    }
		
});

function startStop(action, div)
{
	var data = 'action=' + action + '&ajax=1';
	var ajax_options = {
	        beforeSend:function () 
	        {
	            jQuery('#ajax-throbber').css('display', 'inline');
	        },
	        complete:function () 
	        {
	        	jQuery('#ajax-throbber').css('display', 'none');
	        },
	        error:function (XMLHttpRequest, textStatus, errorThrown) 
	        {
	            alert('There was an error durring request. Please try again later!');
	        },
	        success:function (response, textStatus) 
	        {
	        	if (div == null) {
	        		$('#ajax-messages p').text(response.message);
		        	$('#ajax-messages').fadeIn();
	        	} else {
	        		$('#' + div + ' p').text(response.message);
		        	$('#' + div).fadeIn();
	        	}
	        	window.setTimeout(function () {
	        		if (div == null) {
	        			$('#ajax-messages').fadeOut('in');
	        		} else {
	        			$('#' + div).fadeOut('in');
	        		}
	        	}, 3000);
	        	return false;
	        },
	        timeout:'100000',
	        type:'POST',
	        dataType:'json',
	        data: data,
	        url:'index.php'
	    };
	$.ajax(ajax_options);
	return false;
}

function StartStopKaliServices(action)
{ 

	var actionmessage='on'
	if ($('input.'+action).is(':checked')) {
		actionmessage='on'; 
	}
	else{
		actionmessage='off';
		action=action.replace(/start/, 'stop');
	}
	//alert (action);

    	var data = 'action=' + action + '&ajax=1';
    	var ajax_options = {
    	        beforeSend:function () 
    	        {
    	            jQuery('#ajax-throbber').css('display', 'inline');
    	        },
    	        complete:function () 
    	        {
    	        	jQuery('#ajax-throbber').css('display', 'none');
    	        },
    	        error:function (XMLHttpRequest, textStatus, errorThrown) 
    	        {
    	            alert('There was an error during request. Please try again later!');
    	        },
    	        success:function (response, textStatus) 
    	        {
    	        	var res = action.replace(/start|stop/, '');
    	        	var string = '<div class="alert alert-info" id="main-alert" style="margin:5px 0 0;" role="alert"><p>' + response.message + '</p></div>';
    	        	jQuery('#' + res+'message').html(string);
    	        	window.setTimeout(function () {
    	        		jQuery('#' + res+'message #main-alert').hide("slow");
    	        		//location.reload(true); 
    	        	}, 3000);
    	        	return false;
    	        },
    	        timeout:'100000',
    	        type:'POST',
    	        dataType:'json',
    	        data: data,
    	        url:'index.php'
    	    };
    	$.ajax(ajax_options);
    	return false;
}

function elevatorClicked(elem)
{
	if($("#" + elem + '-elevated').is(':checked')) {
		$("#" + elem + '-platform').show();
	} else {
		$("#" + elem + '-platform').hide();
	}
}

function elevatorFormSubmited(form)
{
	var data = $('#' + form + '-elevator-form').serialize();
	data += '&ajax=1';
	var ajax_options = {
	        beforeSend:function () 
	        {
	            jQuery('#ajax-throbber').css('display', 'inline');
	        },
	        complete:function () 
	        {
	        	jQuery('#ajax-throbber').css('display', 'none');
	        },
	        error:function (XMLHttpRequest, textStatus, errorThrown) 
	        {
	            alert('There was an error durring request. Please try again later!');
	        },
	        success:function (response, textStatus) 
	        {
	        	var string = '<div class="alert alert-info" id="main-alert" style="margin:5px 0 0;" role="alert"><p>' + response + '</p></div>';
	        	jQuery('#' + form + '-tab').after(string);
	        	window.setTimeout(function () {
	        		jQuery('#main-alert').remove();
	        	}, 3000);
	        	return false;
	        },
	        timeout:'100000',
	        type:'GET',
	        dataType:'html',
	        data: data,
	        url:'index.php'
	    };
	$.ajax(ajax_options);
	return false;
}

function resetUsb(form)
{
	var data = 'action=resetusb&ajax=1';
	var ajax_options = {
	        beforeSend:function () 
	        {
	            jQuery('#ajax-throbber').css('display', 'inline');
	        },
	        complete:function () 
	        {
	        	jQuery('#ajax-throbber').css('display', 'none');
	        },
	        error:function (XMLHttpRequest, textStatus, errorThrown) 
	        {
	            alert('There was an error durring request. Please try again later!');
	        },
	        success:function (response, textStatus) 
	        {
	        	var string = '<div class="alert alert-info" id="main-alert" style="margin:5px 0 0;" role="alert"><p>' + response.message + '</p></div>';
	        	jQuery('#' + form + '-tab').after(string);
	        	window.setTimeout(function () {
	        		jQuery('#main-alert').remove();
	        	}, 3000);
	        	return false;
	        },
	        timeout:'100000',
	        type:'POST',
	        dataType:'json',
	        data: data,
	        url:'index.php'
	    };
	$.ajax(ajax_options);
	return false;
}

function getExternalIp()
{
	var data = 'action=getexternalip&ajax=1';
	var ajax_options = {
	        beforeSend:function () 
	        {
	            jQuery('#ajax-throbber').css('display', 'inline');
	        },
	        complete:function () 
	        {
	        	jQuery('#ajax-throbber').css('display', 'none');
	        },
	        error:function (XMLHttpRequest, textStatus, errorThrown) 
	        {
	            alert('There was an error durring request. Please try again later!');
	        },
	        success:function (response, textStatus) 
	        {
	        	jQuery('#external-ip').text(response.message);
	        	jQuery('#external-ip').css('text-align', 'left');
	        	jQuery('#external-ip-btn').remove();
	        	return false;
	        },
	        timeout:'100000',
	        type:'POST',
	        dataType:'json',
	        data: data,
	        url:'index.php'
	    };
	$.ajax(ajax_options);
	return false;

}

function startStopMana(act)
{
	var scr = jQuery('#ddvalue').text();
	var action = act + 'mana';
	var data = 'action=' + action + '&script=' + scr + '&ajax=1';
	var ajax_options = {
	        beforeSend:function () 
	        {
	            jQuery('#ajax-throbber').css('display', 'inline');
	        },
	        complete:function () 
	        {
	        	jQuery('#ajax-throbber').css('display', 'none');
	        },
	        error:function (XMLHttpRequest, textStatus, errorThrown) 
	        {
	            alert('There was an error durring request. Please try again later!');
	        },
	        success:function (response, textStatus) 
	        {
	        	if (div == null) {
	        		$('#ajax-messages p').text(response.message);
		        	$('#ajax-messages').fadeIn();
	        	} else {
	        		$('#' + div + ' p').text(response.message);
		        	$('#' + div).fadeIn();
	        	}
	        	window.setTimeout(function () {
	        		if (div == null) {
	        			$('#ajax-messages').fadeOut('in');
	        		} else {
	        			$('#' + div).fadeOut('in');
	        		}
	        	}, 3000);
	        	return false;
	        },
	        timeout:'100000',
	        type:'POST',
	        dataType:'json',
	        data: data,
	        url:'index.php'
	    };
	$.ajax(ajax_options);
	return false;
}

function manaScriptSelect(label)
{
	jQuery('#ddvalue').text(label);
}